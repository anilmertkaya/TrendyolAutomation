package com.qa.base;

import com.qa.pages.pages.HomePage;
import com.qa.pages.tests.HomePageTests;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import javafx.scene.layout.Priority;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.FindBy;

import java.net.MalformedURLException;
import java.net.URL;

public class TestBase {

    public static AppiumDriver<WebElement> driver;

    @BeforeClass
    public static void Setup() throws MalformedURLException {

        DesiredCapabilities cap = new DesiredCapabilities();
        cap.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
        cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Galaxy S8");
        cap.setCapability("noReset", true);
        cap.setCapability("appPackage", "trendyol.com");
        cap.setCapability("appActivity", "com.trendyol.ui.splash.SplashActivity");
        driver = new AndroidDriver<WebElement>(new URL("http://0.0.0.0:4723/wd/hub"), cap);
    }

    @Test
    public void SimpleTest(){

    }


    //Common Elements Group
    //Alt tab bars
    @FindBy(id = "tab_home") //Ana sayfa Alt tabbar
    public  WebElement anaSayfaTab;

    @FindBy(xpath = "//*[contains(@resource-id,'tab_home')]/*[contains(@resource-id,'icon')]") //Ana sayfa alt tabbar icon
    public WebElement anaSayfaTabIcon;

    @FindBy(id = "largeLabel")  //Ana sayfa alt tabbar text
    public WebElement anaSayfaTabbarText;

    @FindBy(id = "tab_search") //Ana sayfa kategoriler tabbar
    public WebElement kategorilerTab;

    @FindBy(xpath = "//*[contains(@resource-id,'tab_search')]/*[contains(@resource-id,'icon')]") //Ana sayfa categoriler alttabbar büyütec icon
    public WebElement kategorilerBuyutecIcon;

    @FindBy(xpath = "//*[contains(@resource-id,'tab_search')]/android.view.ViewGroup/*[contains(@resource-id,'smallLabel')]")//Ana sayfa kategoriler alt tabbar kategoriler text
    public WebElement kategorilerTabbarText;

    @FindBy(id = "tab_favorites") //Favorilerim tabbar
    public WebElement favorilerimTab;

    @FindBy(xpath = "//*[contains(@resource-id,'tab_favorites')]/*[contains(@resource-id,'icon')]")
    public  WebElement favorilerimTabIcon;

    @FindBy(xpath = "//*[contains(@resource-id,'tab_favorites')]/android.view.ViewGroup/*[contains(@resource-id,'smallLabel')]")
    public WebElement favorilerimTabText;

    @FindBy(id = "tab_basket") //Sepetim tabbar
    public WebElement sepetimTabbar;

    @FindBy(xpath = "//*[contains(@resource-id,'tab_basket')]/*[contains(@resource-id,'icon')]")
    public WebElement sepetimTabIcon;

    @FindBy(xpath = "//*[contains(@resource-id,'tab_basket')]/android.view.ViewGroup/*[contains(@resource-id,'smallLabel')]")
    public WebElement sepetimTabText;

    @FindBy(id = "tab_account") //Hesabım tabbar
    public WebElement hesabimTabbar;

    @FindBy(xpath = "//*[contains(@resource-id,'tab_account')]/*[contains(@resource-id,'icon')]")
    public WebElement hesabimTabIcon;

    @FindBy(xpath = "//*[contains(@resource-id,'tab_account')]/android.view.ViewGroup/*[contains(@resource-id,'smallLabel')]")
    public WebElement hesabimTabText;



}
