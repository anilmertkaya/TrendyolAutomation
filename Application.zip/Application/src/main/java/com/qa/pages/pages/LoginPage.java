package com.qa.pages.pages;

import com.qa.base.TestBase;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends TestBase {

    //LoginPage

    @FindBy(id = "imageViewTrendyolLogo")
    public WebElement trendyolLogo;

    @FindBy(id = "textViewTrendyolSlogan")  //"Yeni sezon trend ürünler seni bekliyor." text
    public WebElement trendyolSlogan;

    @FindBy(id = "editTextEmail")   //E-posta textbox
    public WebElement epostaGiris;

    @FindBy(id = "editTextPassword")    //Şifre textbox
    public WebElement sifreGiris;

    @FindBy(id = "text_input_end_icon")    //Şifre Göster Buttonu
    public WebElement sifreGosterBtn;

    @FindBy(id = "textViewForgotPassword")  //Şifremi unuttum buttonu
    public WebElement sifremiUnuttumBtn;

    @FindBy(id = "buttonLogin") //Giriş yap buttonu
    public WebElement girisYapBtn;

    @FindBy(id = "buttonFacebookLogin") //facebook layout
    public WebElement facebookLayout;

    @FindBy(xpath = "//*[contains(@resource-id,'buttonFacebookLogin')]/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ImageView")
    public WebElement facebookIcon;

    @FindBy(xpath = "//*[contains(@resource-id,'buttonFacebookLogin')]/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.TextView")
    public WebElement facebookBaglanText;   //Facebook ile baglan text

    @FindBy(id = "buttonGoogleLogin")   //Google ile baglan Layout
    public WebElement googleLayout;

    @FindBy(xpath = "//*[contains(@resource-id,'buttonGoogleLogin')]/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ImageView")
    public WebElement googleBaglanIcon;

    @FindBy(xpath = "//*[contains(@resource-id,'buttonGoogleLogin')]/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.TextView")
    public WebElement googleBaglanText; //Google ile baglan text

    @FindBy(id = "textViewRegister")    //Üye değil misin? Üye Ol btn
    public WebElement uyeOlBtn;

    @FindBy(id = "textinput_error") //Lütfen geçerli bir e-posta girin error text
    public WebElement epostaErrorText;

    @FindBy(id = "textinput_error") //Şifreniz 6 - 16 karakter arasında olmalıdır.
    public WebElement sifreErrorText;

    @FindBy(id = "snackbar_text")   //E-posta adresiniz ve/veya şifreniz hatalı.
    public WebElement snacbarErrorText;

    //Initializing the Page Objects
    public LoginPage(AppiumDriver<WebElement> driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    //Actions
    public boolean verifyTrendyolLogo(){
        return trendyolLogo.isDisplayed();
    }

    public boolean verifyTrendyolSlogan(){
        return trendyolSlogan.isDisplayed();
    }
    public boolean verifyEpostaTextbox(){
        return epostaGiris.isDisplayed();
    }
    public boolean verifySifre(){
        return sifreGiris.isDisplayed();
    }
    public boolean verifySifreGosterBtn(){
        return sifreGosterBtn.isDisplayed();
    }
    public boolean verifySifremiUnuttum(){
        return sifremiUnuttumBtn.isDisplayed();
    }
    public boolean verifyGirisYapBtn(){
        return girisYapBtn.isDisplayed();
    }
    public boolean verifyFacebookLayout(){
        return facebookLayout.isDisplayed();
    }
    public boolean verifyGoogleLayout(){
        return googleLayout.isDisplayed();
    }
    public boolean verifyUyeOl(){
        return uyeOlBtn.isDisplayed();
    }
    public boolean verifyEpostaErrorText(){
        return epostaErrorText.isDisplayed();
    }
    public boolean verifySifreErrorText(){
        return sifreErrorText.isDisplayed();
    }

    public HesabimPage login(String eposta, String sifre){
        epostaGiris.sendKeys(eposta);
        sifreGiris.sendKeys(sifre);
        girisYapBtn.click();
        return new HesabimPage(driver);
    }
}
