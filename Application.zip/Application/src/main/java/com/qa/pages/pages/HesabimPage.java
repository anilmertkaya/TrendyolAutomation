package com.qa.pages.pages;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HesabimPage {

    @FindBy(id = "imageViewNotification")
    public WebElement imageViewNotification;

    //Initializing the Page Objects
    public HesabimPage(AppiumDriver<WebElement> driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    //Actions
    public boolean verifyTrendyolLogo(){

        return imageViewNotification.isDisplayed();
    }

}
