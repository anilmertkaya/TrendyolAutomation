package com.qa.pages.pages;

import com.qa.base.TestBase;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends TestBase {

    //Ana sayfa element
    @FindBy(id = "imageViewNotification")   //Ana sayfa zil iconu
    public WebElement notificationIcon;

    @FindBy(id = "imageview_action_start")  //Arama alanı büyüteç ikon
    public WebElement aramaAlaniBuyutecIcon;


    //Initializing Page Objects
    public HomePage(AppiumDriver<WebElement> driver){
        PageFactory.initElements(new AppiumFieldDecorator(driver),this);
    }

    //Actions
    public boolean verifyNotificationIcon(){
        return notificationIcon.isDisplayed();
    }
}
