package com.qa.pages.pages;

import com.qa.base.TestBase;

public class RegisterPage extends TestBase {
}
