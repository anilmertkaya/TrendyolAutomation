package com.qa.pages.tests;

import com.qa.base.TestBase;
import com.qa.pages.pages.HomePage;
import org.testng.annotations.BeforeMethod;

public class HomePageTests extends TestBase {
    HomePage homePage = new HomePage(driver);

    public HomePageTests(){
        super();
    }

    @BeforeMethod
    public void SetUp(){
    }
}
